declare const flush: () => Promise<void>

export = flush
