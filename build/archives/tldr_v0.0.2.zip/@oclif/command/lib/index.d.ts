import Command from './command';
import * as flags from './flags';
export { run, Main } from './main';
export default Command;
export { Command, flags, };
