import { List } from '../interfaces';
export declare function renderList(items: List): string;
