@oclif/color
============



[![oclif](https://img.shields.io/badge/cli-oclif-brightgreen.svg)](https://oclif.io)
[![Version](https://img.shields.io/npm/v/@oclif/color.svg)](https://npmjs.org/package/@oclif/color)
[![CircleCI](https://circleci.com/gh/oclif/color/tree/main.svg?style=shield)](https://circleci.com/gh/oclif/color/tree/main)
[![Appveyor CI](https://ci.appveyor.com/api/projects/status/github/oclif/color?branch=main&svg=true)](https://ci.appveyor.com/project/oclif/color/branch/main)
[![Downloads/week](https://img.shields.io/npm/dw/@oclif/color.svg)](https://npmjs.org/package/@oclif/color)
[![License](https://img.shields.io/npm/l/@oclif/color.svg)](https://github.com/oclif/color/blob/main/package.json)

<!-- toc -->
# Usage
<!-- usage -->
# Commands
<!-- commands -->
