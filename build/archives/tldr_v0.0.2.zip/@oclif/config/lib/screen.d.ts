export declare const stdtermwidth: number;
export declare const errtermwidth: number;
