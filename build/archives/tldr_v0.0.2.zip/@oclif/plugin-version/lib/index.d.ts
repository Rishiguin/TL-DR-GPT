export { VersionDetail, default as VersionCommand } from './commands/version';
