@oclif/plugin-version
======================

An oclif command that shows the CLI version

[![Version](https://img.shields.io/npm/v/@oclif/plugin-version.svg)](https://npmjs.org/package/@oclif/plugin-version)
[![CircleCI](https://circleci.com/gh/oclif/plugin-version/tree/main.svg?style=svg)](https://circleci.com/gh/oclif/plugin-version/tree/main)
[![Downloads/week](https://img.shields.io/npm/dw/@oclif/plugin-version.svg)](https://npmjs.org/package/@oclif/plugin-version)
[![License](https://img.shields.io/npm/l/@oclif/plugin-update.svg)](https://github.com/oclif/plugin-version/blob/main/package.json)
