steamship-cli
=============

A command line tool for Steamship, the fastest way to add Language AI to your software.

[![oclif](https://img.shields.io/badge/cli-oclif-brightgreen.svg)](https://oclif.io)
[![Version](https://img.shields.io/npm/v/@steamship/cli.svg)](https://npmjs.org/package/@steamship/cli)
[![Downloads/week](https://img.shields.io/npm/dw/@steamship/cli.svg)](https://npmjs.org/package/@steamship/cli)
[![License](https://img.shields.io/npm/l/@steamship/cli.svg)](https://github.com/nludb/nludb-cli/blob/master/package.json)

Quick setup:

```bash
npm install -g @steamship/cli
ship login
ship create
```

Then follow the instructions in the resulting README.md file of your starter project.

<!-- toc -->
* [Usage](#usage)
* [Commands](#commands)
<!-- tocstop -->

# Usage

<!-- usage -->
```sh-session
$ npm install -g @steamship/cli
$ ship COMMAND
running command...
$ ship (--version|-v)
@steamship/cli/2.2.9 linux-x64 node-v14.21.2
$ ship --help [COMMAND]
USAGE
  $ ship COMMAND
...
```
<!-- usagestop -->

# Commands

<!-- commands -->
* [`ship create [HANDLE]`](#ship-create-handle)
* [`ship deploy`](#ship-deploy)
* [`ship help [COMMAND]`](#ship-help-command)
* [`ship login`](#ship-login)
* [`ship package:deploy`](#ship-packagedeploy)
* [`ship package:instance:create`](#ship-packageinstancecreate)
* [`ship package:instance:delete`](#ship-packageinstancedelete)
* [`ship package:instance:invoke`](#ship-packageinstanceinvoke)
* [`ship package:instance:list`](#ship-packageinstancelist)
* [`ship package:list`](#ship-packagelist)
* [`ship package:update`](#ship-packageupdate)
* [`ship package:version:list`](#ship-packageversionlist)
* [`ship plugin:deploy`](#ship-plugindeploy)
* [`ship plugin:instance:create`](#ship-plugininstancecreate)
* [`ship plugin:instance:delete`](#ship-plugininstancedelete)
* [`ship plugin:instance:list`](#ship-plugininstancelist)
* [`ship plugin:list`](#ship-pluginlist)
* [`ship plugin:update`](#ship-pluginupdate)
* [`ship plugin:version:list`](#ship-pluginversionlist)
* [`ship project:bundle`](#ship-projectbundle)
* [`ship project:get [PROPERTY]`](#ship-projectget-property)
* [`ship project:sync-docs`](#ship-projectsync-docs)
* [`ship run INSTANCE`](#ship-run-instance)
* [`ship task:info`](#ship-taskinfo)
* [`ship task:list`](#ship-tasklist)
* [`ship try [HANDLE]`](#ship-try-handle)
* [`ship update`](#ship-update)
* [`ship user:handle:set [HANDLE]`](#ship-userhandleset-handle)
* [`ship user:info`](#ship-userinfo)
* [`ship version`](#ship-version)
* [`ship workspace:delete`](#ship-workspacedelete)
* [`ship workspace:list`](#ship-workspacelist)

## `ship create [HANDLE]`

Creates a new Steamship Package or Plugin

```
USAGE
  $ ship create [HANDLE]

ARGUMENTS
  HANDLE  The new project handle.

DESCRIPTION
  Creates a new Steamship Package or Plugin

EXAMPLES
  $ ship create project-handle
```

_See code: [dist/commands/create.ts](https://github.com/steamship-core/steamship-cli/blob/v2.2.9/dist/commands/create.ts)_

## `ship deploy`

Deploys a Steamship Package or Plugin from a project's root folder.

```
USAGE
  $ ship deploy [-h]

FLAGS
  -h, --help  Show CLI help.

DESCRIPTION
  Deploys a Steamship Package or Plugin from a project's root folder.

EXAMPLES
  $ ship deploy
```

_See code: [dist/commands/deploy.ts](https://github.com/steamship-core/steamship-cli/blob/v2.2.9/dist/commands/deploy.ts)_

## `ship help [COMMAND]`

Display help for ship.

```
USAGE
  $ ship help [COMMAND] [-n]

ARGUMENTS
  COMMAND  Command to show help for.

FLAGS
  -n, --nested-commands  Include all nested commands in the output.

DESCRIPTION
  Display help for ship.
```

_See code: [@oclif/plugin-help](https://github.com/oclif/plugin-help/blob/v5.1.22/src/commands/help.ts)_

## `ship login`

Logs in to Steamship

```
USAGE
  $ ship login [-a <value>] [-s <value>] [-t <value>]

FLAGS
  -a, --api_domain=<value>   The API domain to login to. Default is https://api.steamship.com/api/v1/
  -s, --site_domain=<value>  The site domain to login to. Default is https://api.steamship.com/api/v1/
  -t, --token=<value>        A previously generated API token to authenticate against.

DESCRIPTION
  Logs in to Steamship

EXAMPLES
  $ ship login

  $ ship login -t 1234-5678-9101-1121

  $ ship login -s https://api.steamship.com/api/v1/ -a https://api.steamship.com
```

_See code: [dist/commands/login.ts](https://github.com/steamship-core/steamship-cli/blob/v2.2.9/dist/commands/login.ts)_

## `ship package:deploy`

Deploys a Steamship Package

```
USAGE
  $ ship package:deploy [--help] [--version]

FLAGS
  --help     Show CLI help.
  --version  Show CLI version.

DESCRIPTION
  Deploys a Steamship Package

EXAMPLES
  $ ship package:deploy

  $ ship package:deploy --version <versionHandle>
```

_See code: [dist/commands/package/deploy.ts](https://github.com/steamship-core/steamship-cli/blob/v2.2.9/dist/commands/package/deploy.ts)_

## `ship package:instance:create`

Creates an instance of a package.

```
USAGE
  $ ship package:instance:create [-h <value>] [-p <value>] [-v <value>]

FLAGS
  -h, --handle=<value>   Handle for the instance.
  -p, --package=<value>  Package handle.
  -v, --version=<value>  Package Version handle.

DESCRIPTION
  Creates an instance of a package.

EXAMPLES
  $ ship package:instance:create
```

_See code: [dist/commands/package/instance/create.ts](https://github.com/steamship-core/steamship-cli/blob/v2.2.9/dist/commands/package/instance/create.ts)_

## `ship package:instance:delete`

Delete an app.

```
USAGE
  $ ship package:instance:delete [-a <value>] [-i <value>]

FLAGS
  -a, --package=<value>   the Package handle
  -i, --instance=<value>  the Package Instance handle

DESCRIPTION
  Delete an app.

EXAMPLES
  $ ship package:instance:delete --instance <instanceHandle>

  $ ship package:instance:delete --package <packageHandle> --instance <instanceHandle>
```

_See code: [dist/commands/package/instance/delete.ts](https://github.com/steamship-core/steamship-cli/blob/v2.2.9/dist/commands/package/instance/delete.ts)_

## `ship package:instance:invoke`

Invokes a method on an package instance.

```
USAGE
  $ ship package:instance:invoke [-p <value>] [-i <value>] [-m <value>] [-v <value>] [-c]

FLAGS
  -c, --curl              Display cURL command to invoke instead of calling.
  -i, --instance=<value>  The Instance Handle
  -m, --method=<value>    [default: /] The method to run
  -p, --package=<value>   The Package Handle
  -v, --verb=<value>      [default: POST] HTTP Verb. Either GET or POST. Defaults to POST.

DESCRIPTION
  Invokes a method on an package instance.

EXAMPLES
  $ ship package:instance:invoke --package hello-world --instance default --method greet --name "Ted"
```

_See code: [dist/commands/package/instance/invoke.ts](https://github.com/steamship-core/steamship-cli/blob/v2.2.9/dist/commands/package/instance/invoke.ts)_

## `ship package:instance:list`

Lists the instances of an Package Version.

```
USAGE
  $ ship package:instance:list [-p <value>]

FLAGS
  -p, --package=<value>  the Package handle

DESCRIPTION
  Lists the instances of an Package Version.

EXAMPLES
  $ ship package:instance:list

  $ ship package:instance:list --package <packageHandle>
```

_See code: [dist/commands/package/instance/list.ts](https://github.com/steamship-core/steamship-cli/blob/v2.2.9/dist/commands/package/instance/list.ts)_

## `ship package:list`

Lists your apps.

```
USAGE
  $ ship package:list

DESCRIPTION
  Lists your apps.

EXAMPLES
  $ ship package:list
```

_See code: [dist/commands/package/list.ts](https://github.com/steamship-core/steamship-cli/blob/v2.2.9/dist/commands/package/list.ts)_

## `ship package:update`

Updates a Steamship Package in the registry

```
USAGE
  $ ship package:update [--help] [--version]

FLAGS
  --help     Show CLI help.
  --version  Show CLI version.

DESCRIPTION
  Updates a Steamship Package in the registry

EXAMPLES
  $ ship package:update
```

_See code: [dist/commands/package/update.ts](https://github.com/steamship-core/steamship-cli/blob/v2.2.9/dist/commands/package/update.ts)_

## `ship package:version:list`

Lists the versions of an Package.

```
USAGE
  $ ship package:version:list [-a <value>]

FLAGS
  -a, --package=<value>  the Package handle

DESCRIPTION
  Lists the versions of an Package.

EXAMPLES
  $ ship package:version:list

  $ ship package:version:list --package <packageHandle>
```

_See code: [dist/commands/package/version/list.ts](https://github.com/steamship-core/steamship-cli/blob/v2.2.9/dist/commands/package/version/list.ts)_

## `ship plugin:deploy`

Deploys a Steamship Plugin

```
USAGE
  $ ship plugin:deploy [--help] [--version]

FLAGS
  --help     Show CLI help.
  --version  Show CLI version.

DESCRIPTION
  Deploys a Steamship Plugin

EXAMPLES
  $ ship plugin:deploy

  $ ship plugin:deploy --version <versionHandle>
```

_See code: [dist/commands/plugin/deploy.ts](https://github.com/steamship-core/steamship-cli/blob/v2.2.9/dist/commands/plugin/deploy.ts)_

## `ship plugin:instance:create`

Creates an instance of the Plugin.

```
USAGE
  $ ship plugin:instance:create [-h <value>] [-p <value>] [-v <value>]

FLAGS
  -h, --handle=<value>   Handle for the instance.
  -p, --plugin=<value>   Plugin handle.
  -v, --version=<value>  Plugin Version handle.

DESCRIPTION
  Creates an instance of the Plugin.

EXAMPLES
  $ ship plugin:instance:create
```

_See code: [dist/commands/plugin/instance/create.ts](https://github.com/steamship-core/steamship-cli/blob/v2.2.9/dist/commands/plugin/instance/create.ts)_

## `ship plugin:instance:delete`

Delete a plugin Instance.

```
USAGE
  $ ship plugin:instance:delete [-p <value>] [-i <value>] [-s <value>]

FLAGS
  -i, --instance=<value>  the Plugin Instance handle
  -p, --plugin=<value>    the Plugin handle
  -s, --space=<value>     the Workspace handle

DESCRIPTION
  Delete a plugin Instance.

EXAMPLES
  $ ship plugin:instance:delete

  $ ship plugin:instance:delete --instance <instanceHandle>

  $ ship plugin:instance:delete --plugin <packageHandle> --instance <instanceHandle>
```

_See code: [dist/commands/plugin/instance/delete.ts](https://github.com/steamship-core/steamship-cli/blob/v2.2.9/dist/commands/plugin/instance/delete.ts)_

## `ship plugin:instance:list`

Lists the instances of an Plugin Version.

```
USAGE
  $ ship plugin:instance:list [-a <value>]

FLAGS
  -a, --plugin=<value>  the Plugin handle

DESCRIPTION
  Lists the instances of an Plugin Version.

EXAMPLES
  $ ship plugin:instance:list

  $ ship plugin:instance:list --plugin <pluginHandle>
```

_See code: [dist/commands/plugin/instance/list.ts](https://github.com/steamship-core/steamship-cli/blob/v2.2.9/dist/commands/plugin/instance/list.ts)_

## `ship plugin:list`

Lists your plugins.

```
USAGE
  $ ship plugin:list [-m]

FLAGS
  -m, --mine  List your own plugins.

DESCRIPTION
  Lists your plugins.

EXAMPLES
  $ ship plugin:list

  $ ship plugin:list --mine
```

_See code: [dist/commands/plugin/list.ts](https://github.com/steamship-core/steamship-cli/blob/v2.2.9/dist/commands/plugin/list.ts)_

## `ship plugin:update`

Updates a Steamship Plugin in the registry

```
USAGE
  $ ship plugin:update [--help] [--version]

FLAGS
  --help     Show CLI help.
  --version  Show CLI version.

DESCRIPTION
  Updates a Steamship Plugin in the registry

EXAMPLES
  $ ship plugin:update
```

_See code: [dist/commands/plugin/update.ts](https://github.com/steamship-core/steamship-cli/blob/v2.2.9/dist/commands/plugin/update.ts)_

## `ship plugin:version:list`

Lists the versions of an Plugin.

```
USAGE
  $ ship plugin:version:list [-p <value>]

FLAGS
  -p, --plugin=<value>  the plugin handle

DESCRIPTION
  Lists the versions of an Plugin.

EXAMPLES
  $ ship plugin:version:list
```

_See code: [dist/commands/plugin/version/list.ts](https://github.com/steamship-core/steamship-cli/blob/v2.2.9/dist/commands/plugin/version/list.ts)_

## `ship project:bundle`

Bundles a deployment package (for testing)

```
USAGE
  $ ship project:bundle [--help]

FLAGS
  --help  Show CLI help.

DESCRIPTION
  Bundles a deployment package (for testing)

EXAMPLES
  $ ship util:bundle
```

_See code: [dist/commands/project/bundle.ts](https://github.com/steamship-core/steamship-cli/blob/v2.2.9/dist/commands/project/bundle.ts)_

## `ship project:get [PROPERTY]`

Returns a property from your steamship.json file

```
USAGE
  $ ship project:get [PROPERTY]

ARGUMENTS
  PROPERTY  Property in steamship.json to fetch. Dot-notation will traverse nested objects.

DESCRIPTION
  Returns a property from your steamship.json file

EXAMPLES
  $ ship project:get name

  $ ship project:get plugin.type
```

_See code: [dist/commands/project/get.ts](https://github.com/steamship-core/steamship-cli/blob/v2.2.9/dist/commands/project/get.ts)_

## `ship project:sync-docs`

Syncs standardized documentation and settings. Will not overwrite without asking.

```
USAGE
  $ ship project:sync-docs [--help] [-s] [-a <value>]

FLAGS
  -a, --all=<value>  skip|overwrite|propose - auto-apply to conflicts
  -s, --simulate     only simulate the sync
  --help             Show CLI help.

DESCRIPTION
  Syncs standardized documentation and settings. Will not overwrite without asking.

EXAMPLES
  $ ship util:sync-docs

  $ ship util:sync-docs --simulate

  $ ship util:sync-docs --all=skip|overwrite|propose
```

_See code: [dist/commands/project/sync-docs.ts](https://github.com/steamship-core/steamship-cli/blob/v2.2.9/dist/commands/project/sync-docs.ts)_

## `ship run INSTANCE`

Runs a Steamship app

```
USAGE
  $ ship run [INSTANCE] [-h] [-i <value>]

ARGUMENTS
  INSTANCE  The package Instance.

FLAGS
  -h, --help           Show CLI help.
  -i, --input=<value>  Input file to use as data input for an app

DESCRIPTION
  Runs a Steamship app

EXAMPLES
  $ ship run --input input1.json
  { result: 'Hello, Steamship' }

  $ ship run --data "{\"name\": \"Steamship\"}"
  { result: 'Hello, Steamship' }
```

_See code: [dist/commands/run.ts](https://github.com/steamship-core/steamship-cli/blob/v2.2.9/dist/commands/run.ts)_

## `ship task:info`

Lists tasks in the Steamship.

```
USAGE
  $ ship task:info -i <value>

FLAGS
  -i, --id=<value>  (required) Task ID

DESCRIPTION
  Lists tasks in the Steamship.

EXAMPLES
  $ ship plugin:task:get --id <taskUuid>
```

_See code: [dist/commands/task/info.ts](https://github.com/steamship-core/steamship-cli/blob/v2.2.9/dist/commands/task/info.ts)_

## `ship task:list`

Lists tasks in the Steamship.

```
USAGE
  $ ship task:list [-t <value>] [-s <value>] [-i <value>]

FLAGS
  -i, --id=<value>     the Task ID
  -s, --space=<value>  the Workspace handle
  -t, --state=<value>  Task Status. succeeded|failed|waiting|running.

DESCRIPTION
  Lists tasks in the Steamship.

EXAMPLES
  $ ship plugin:task:list

  $ ship plugin:task:list --state <succeeded|failed|waiting|running>

  $ ship plugin:task:list --space <spaceHandle>

  $ ship plugin:task:list --id <taskUuid>
```

_See code: [dist/commands/task/list.ts](https://github.com/steamship-core/steamship-cli/blob/v2.2.9/dist/commands/task/list.ts)_

## `ship try [HANDLE]`

Downloads a Jupyter demo of a Steamship Package or Plugin.

```
USAGE
  $ ship try [HANDLE]

ARGUMENTS
  HANDLE  The package or plugin handle.

DESCRIPTION
  Downloads a Jupyter demo of a Steamship Package or Plugin.

EXAMPLES
  $ ship try <app-or-plugin-name>
```

_See code: [dist/commands/try.ts](https://github.com/steamship-core/steamship-cli/blob/v2.2.9/dist/commands/try.ts)_

## `ship update`

Updates a Steamship Package or Plugin from a project's root folder.

```
USAGE
  $ ship update [-h]

FLAGS
  -h, --help  Show CLI help.

DESCRIPTION
  Updates a Steamship Package or Plugin from a project's root folder.

EXAMPLES
  $ ship update
```

_See code: [dist/commands/update.ts](https://github.com/steamship-core/steamship-cli/blob/v2.2.9/dist/commands/update.ts)_

## `ship user:handle:set [HANDLE]`

Sets your user handle.

```
USAGE
  $ ship user:handle:set [HANDLE]

DESCRIPTION
  Sets your user handle.

EXAMPLES
  $ ship user:handle:set <new-handle>
```

_See code: [dist/commands/user/handle/set.ts](https://github.com/steamship-core/steamship-cli/blob/v2.2.9/dist/commands/user/handle/set.ts)_

## `ship user:info`

Displays information about the current Steamship CLI and authentication

```
USAGE
  $ ship user:info

DESCRIPTION
  Displays information about the current Steamship CLI and authentication

EXAMPLES
  $ ship user:info
```

_See code: [dist/commands/user/info.ts](https://github.com/steamship-core/steamship-cli/blob/v2.2.9/dist/commands/user/info.ts)_

## `ship version`

```
USAGE
  $ ship version [--json] [--verbose]

FLAGS
  --verbose  Show additional information about the CLI.

GLOBAL FLAGS
  --json  Format output as json.

FLAG DESCRIPTIONS
  --verbose  Show additional information about the CLI.

    Additionally shows the architecture, node version, operating system, and versions of plugins that the CLI is using.
```

_See code: [@oclif/plugin-version](https://github.com/oclif/plugin-version/blob/v1.1.4/src/commands/version.ts)_

## `ship workspace:delete`

Delete a Workspace.

```
USAGE
  $ ship workspace:delete [-h <value>]

FLAGS
  -h, --handle=<value>  the workspace handle

DESCRIPTION
  Delete a Workspace.

EXAMPLES
  $ ship workspace:delete <handle>
```

_See code: [dist/commands/workspace/delete.ts](https://github.com/steamship-core/steamship-cli/blob/v2.2.9/dist/commands/workspace/delete.ts)_

## `ship workspace:list`

Lists your workspaces.

```
USAGE
  $ ship workspace:list

DESCRIPTION
  Lists your workspaces.

EXAMPLES
  $ ship workspace:list
```

_See code: [dist/commands/workspace/list.ts](https://github.com/steamship-core/steamship-cli/blob/v2.2.9/dist/commands/workspace/list.ts)_
<!-- commandsstop -->
