import uuid
import os

from steamship import  Steamship
from steamship.invocable import post, longstr
from enum import Enum 
from prompt_service import PromptService 

class InputType(str, Enum): 
  ARTICLE = "article"
  MEETING_TRANSCRIPT = "meeting_transcript"

class Intent(str, Enum): 
  BASIC_SUMMARY = "basic"
  GOOD_MORNING_EMAIL = "good_morning"
  
class TLDRPackage(PromptService):

  PROMPT_TEMPLATE = """Act as an executive assistant and write an executive summary of a {input_type}. Write the summary as a bulleted list. Focus on the key message and skip side information. Keep each bullet short and less than 20 words by removing fluffy words. Keep your output under {max_n_tokens} tokens. {additional_instructions}
  
  {input_type}: {text}."""

  PROMPT_TEMPERATURE = 0.8
  MAX_WORDS = 400
  REDUCTION_FACTOR = .05
  MIN_N_TOKENS = 50

  @post("generate")
  def generate(self, text: longstr, input_type: InputType = InputType.ARTICLE, intent: Intent = Intent.BASIC_SUMMARY) -> str:
    """Generate text from prompt parameters."""

    n_tokens = len(text.split())

    max_n_tokens = max(n_tokens * self.REDUCTION_FACTOR, self.MIN_N_TOKENS)

      
    additional_instructions = ""
    if input_type == InputType.MEETING_TRANSCRIPT:
        additional_instructions = """Extract the action items from the meeting using the following template: 
        
      Action items 
      ===
      1. Action item 1 - Assigne
      
      """
    
    prompt_text = self.PROMPT_TEMPLATE.format(text=text,
                                              max_n_tokens=max_n_tokens,
                                              input_type="news article",
                                             additional_instructions=additional_instructions)

    return self.complete_prompt(prompt_text)

if __name__ == "__main__":
  client = Steamship(api_key=os.environ.get('STEAMSHIP_API_KEY'))

  client.switch_workspace(str(uuid.uuid4()))

  package = TLDRPackage(client)


  import inspect 
  parameters = inspect.signature(package.generate).parameters

  kwargs = {}
  for parameter in parameters: 
    kwargs[parameter] = input(f'Provide a value for {parameter}: ')
  
  print("Going to complete your prompt 5 times with the given inputs:")
  for i in range(2):
    print(f"Run {i+1}\n---\n{package.generate(**kwargs)}\n---")


  client.get_workspace().delete()
