# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [2.2.10](https://github.com/steamship-core/typescript-client/compare/v2.2.8...v2.2.10) (2022-11-23)

### [2.2.8](https://github.com/steamship-core/typescript-client/compare/v2.0.2...v2.2.8) (2022-11-23)

## [2.1.0](https://github.com/nludb/typescript-client/compare/v2.0.2...v2.1.0) (2022-10-22)

### [1.0.29](https://github.com/nludb/typescript-client/compare/v1.0.27...v1.0.29) (2021-09-08)

### [1.0.27](https://github.com/nludb/typescript-client/compare/v1.0.25...v1.0.27) (2021-09-08)

### [1.0.25](https://github.com/nludb/typescript-client/compare/v1.0.23...v1.0.25) (2021-09-08)

### 1.0.23 (2021-09-08)

### [1.0.22](https://github.com/nludb/typescript-client/compare/v1.0.20...v1.0.22) (2021-08-24)

### [1.0.20](https://github.com/nludb/typescript-client/compare/v1.0.18...v1.0.20) (2021-08-24)

### [1.0.18](https://github.com/nludb/typescript-client/compare/v1.0.16...v1.0.18) (2021-08-24)

### [1.0.16](https://github.com/nludb/typescript-client/compare/v1.0.14...v1.0.16) (2021-08-24)

### [1.0.14](https://github.com/nludb/typescript-client/compare/v1.0.12...v1.0.14) (2021-08-24)

### [1.0.12](https://github.com/nludb/typescript-client/compare/v1.0.10...v1.0.12) (2021-08-23)

### [1.0.10](https://github.com/nludb/typescript-client/compare/v1.0.8...v1.0.10) (2021-07-05)

### [1.0.8](https://github.com/nludb/typescript-client/compare/v1.0.6...v1.0.8) (2021-07-05)

### [1.0.6](https://github.com/nludb/typescript-client/compare/v1.0.4...v1.0.6) (2021-07-05)

### [1.0.4](https://github.com/nludb/typescript-client/compare/v1.0.3...v1.0.4) (2021-07-05)

### [1.0.3](https://github.com/nludb/typescript-client/compare/v1.0.1...v1.0.3) (2021-06-18)

### 1.0.1 (2021-06-03)
