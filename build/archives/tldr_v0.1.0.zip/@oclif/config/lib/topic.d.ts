export interface Topic {
    name: string;
    description?: string;
    hidden?: boolean;
}
