module.exports = require('./lib').flush
