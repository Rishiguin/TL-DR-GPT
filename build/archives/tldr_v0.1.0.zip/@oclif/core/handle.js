module.exports = error => require('./lib/errors/handle').handle(error)
