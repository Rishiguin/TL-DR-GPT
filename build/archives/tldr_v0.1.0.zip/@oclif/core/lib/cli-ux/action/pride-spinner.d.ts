import SpinnerAction from './spinner';
export default class PrideSpinnerAction extends SpinnerAction {
    protected _frame(): string;
}
