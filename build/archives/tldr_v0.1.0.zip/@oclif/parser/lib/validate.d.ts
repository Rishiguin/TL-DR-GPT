import { ParserInput, ParserOutput } from './parse';
export declare function validate(parse: {
    input: ParserInput;
    output: ParserOutput<any, any>;
}): void;
