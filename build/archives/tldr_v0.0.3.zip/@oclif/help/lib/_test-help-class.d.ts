import { HelpBase } from '.';
export default class extends HelpBase {
    showHelp(): void;
    showCommandHelp(): void;
    getCommandHelpForReadme(): string;
}
