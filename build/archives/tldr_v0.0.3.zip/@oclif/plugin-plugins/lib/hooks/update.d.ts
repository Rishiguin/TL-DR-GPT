import { Hook } from '@oclif/core';
export declare const update: Hook<'update'>;
