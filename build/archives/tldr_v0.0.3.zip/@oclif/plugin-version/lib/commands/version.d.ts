import { Command } from '@oclif/core';
export interface VersionDetail {
    cliVersion: string;
    architecture: string;
    nodeVersion: string;
    pluginVersions?: string[];
    osVersion?: string;
    shell?: string;
    rootPath?: string;
}
export default class Version extends Command {
    static enableJsonFlag: boolean;
    static flags: {
        verbose: import("@oclif/core/lib/interfaces").BooleanFlag<boolean>;
    };
    run(): Promise<VersionDetail>;
    private getFriendlyName;
}
