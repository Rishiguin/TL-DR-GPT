@oclif/errors
==============

**This library has been replaced by [@oclif/core](https://github.com/oclif/core) and is now in maintenance mode. We will only consider PRs that address security concerns.**

display friendly CLI errors and log to error log

[![Version](https://img.shields.io/npm/v/@oclif/errors.svg)](https://npmjs.org/package/@oclif/errors)
[![CircleCI](https://circleci.com/gh/oclif/errors/tree/main.svg?style=svg)](https://circleci.com/gh/oclif/errors/tree/main)
[![Appveyor CI](https://ci.appveyor.com/api/projects/status/github/oclif/errors?branch=main&svg=true)](https://ci.appveyor.com/project/heroku/errors/branch/main)
[![Known Vulnerabilities](https://snyk.io/test/npm/@oclif/errors/badge.svg)](https://snyk.io/test/npm/@oclif/errors)
[![Downloads/week](https://img.shields.io/npm/dw/@oclif/errors.svg)](https://npmjs.org/package/@oclif/errors)
[![License](https://img.shields.io/npm/l/@oclif/errors.svg)](https://github.com/oclif/errors/blob/main/package.json)
